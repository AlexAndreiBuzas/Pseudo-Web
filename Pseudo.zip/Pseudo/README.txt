Dacă citești acest fișier înseamna că folosești Pseudo pentru prima dată.

În acest fișier se vor acoperi următoarele teme:
	1. Instalarea .Net
	2. Adăugarea executabilului la Path
	3. Utilizare și observații despre program

Instalarea .Net

Pe langă fișierele programului Pseudo a fost adăugat un folder numit .Net, in care se află
un instalator pentru .Net, de asemenea se poate descărca accesand link-ul următor:
	- https://dotnet.microsoft.com/en-us/download/dotnet/5.0

Adăugarea executabilului la Path (necesită permisiuni de administrator)

Pentru Windows instalat in limba română:
	1. Căutăm în Windows Search 'Editarea variabilelor de mediu ale sistemului'
	2. Apăsăm pe primul rezultat
	3. În meniul nou deschis, apăsăm pe butonul 'Variabile de mediu'
	4. În secțiunea 'Variabile sistem', selectăm din listă elementul 'Path' și apăsăm butonul 'Editare'
	5. Copiem calea (locația) unde sunt localizate fișierele programului Pseudo
	6. Apăsăm 'Nou' in meniul 'Editati variabila de mediu'
	7. Lipim locația în căsuța nou creată
	8. Apăsăm ok pentru a închide toate meniurile

Pentru Windows instalat in limba engleza:
	1. Căutăm în Windows Search 'Edit the system environment variables'
	2. Apăsăm pe primul rezultat
	3. În meniul nou deschis, apăsăm pe butonul 'Environment Variables'
	4. În secțiunea 'System variables', selectăm din listă elementul 'Path' și apăsăm butonul 'Edit'
	5. Copiem calea (locația) unde sunt localizate fișierele programului Pseud
	6. Apăsăm 'New' în meniul 'Edit environment variables'
	7. Lipim locația în căsuța nou creată
	8. Apăsăm ok pentru a închide toate meniurile

Utilizare și observații despre program

Deoarece pseudocodul nu a fost conceput pentru a putea fi compilat sau interpretat pe un calculator, s-au dezvoltat de-a lungul timpului mai multe variante.
Pseudo rezolvă această problemă prin funcția de definire a variantelor. În folderul / directorul unde sunt localizate fișierele programului, există un folder / director numit
'variante'. În acesta se află o variantă standard, care poate fi deschisă sau copiată și editată.

ATENTIE! Schimbările extreme într-o variantă pot duce la erori sau bug-uri. Sugerăm ca modificările să fie decente!

După adăugarea la Path, programul Pseudo poate să fie executat în orice locatie, folosind terminalul.
Detalii esențiale pentru folosirea terminalului și a programului Pseudo:
	- Deschidem terminalul căutând în Windows Search 'cmd'
	- Putem merge intr-un folder / director folosind comanda 'cd <cale (locatie)>'. Locatia o copiem din Explorer sau o scriem manual
	- Putem genera varianta standard pentru Pseudo folosind comanda 'pseudo -generare' sau 'pseudo -g'
	- Putem începe interpretarea codului scris în pseudocod folosind comanda 'pseudo -simulare <nume_fișier>.<extensie> <variantă>'
	  sau 'pseudo -s <nume_fișier>.<extensie> <variantă>'. Fișierul trebuie să fie în folderul / directorul actual în care vă aflați folosind terminalul.
	  Varianta se referă la numele fișierului de variantă, fără extensie, definit in fișierele programului.

Pseudo acceptă programare doar la nivel de numere, alte tipuri de date fiind nedefinite!